<!DOCTYPE html>
<html lang="sr">
  <head>
    <title>Crystal Medical - Estetska i rekonstruktivna hirurgija u Beogradu</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />

    <!-- SEO META -->
    <meta
      name="description"
      content="Crystal Medical pruža estetsku i rekonstruktivnu hirurgiju, nehirurške tretmane i korekciju ožiljaka. Individualni plan, jasno objašnjena očekivanja i bezbedan oporavak. Tim predvođen dr Mihailom Jakšić."
    />
    <meta
      name="keywords"
      content="estetska hirurgija beograd, plastična hirurgija beograd, rinoplastika, blefaroplastika, liposukcija, botoks, fileri, PRP, mezoterapija, korekcija ožiljaka, rekonstruktivna hirurgija, labioplastika"
    />

    <link rel="icon" href="images/logo_2.ico"  type="image/x-icon">

    <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.css" />

    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />

    <link rel="stylesheet" href="css/aos.css" />

    <link rel="stylesheet" href="css/ionicons.min.css" />

    <link rel="stylesheet" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="css/jquery.timepicker.css" />

    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/icomoon.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css"
      integrity="sha512-nNlU0WK2QfKsuEmdcTwkeh+lhGs6uyOxuUs+n+0oXSYDok5qy0EI0lt01ZynHq6+p/tbgpZ7P+yUb+r71wqdXg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>
  <body>
    <nav
      class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div class="container">
        <a class="navbar-brand" href="index.php">
          <img id="logo" src="images/logo_1.png" alt="" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a href="index.php" class="nav-link">POČETNA</a>
            </li>
            <li class="nav-item">
              <a href="o-nama.html" class="nav-link">O NAMA</a>
            </li>
            <li class="nav-item">
              <a href="usluge.html" class="nav-link">USLUGE</a>
            </li>
            <li class="nav-item">
              <a href="cenovnik.html" class="nav-link">CENOVNIK</a>
            </li>
            <li class="nav-item">
              <a href="blog.html" class="nav-link">BLOG</a>
            </li>
            <li class="nav-item">
              <a href="kontakt.php" class="nav-link">KONTAKT</a>
            </li>

            <li class="nav-item">
              <a href="index-uk.php" class="nav-link">
                <img
                  src="images/uk-zastava.png"
                  alt=""
                  style="height: 20px; width: 40px; border: 0.5px solid #154d32"
                />
              </a>
            </li>
            <li class="nav-item">
              <a href="index-ru.php" class="nav-link">
                <img
                  src="images/ruski-jezik.png"
                  alt=""
                  style="height: 20px; width: 40px; border: 0.5px solid #154d32"
                />
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <!-- HERO SLIDER -->
    <section class="home-slider owl-carousel">
      <!-- SLIDE 1 – novi hero copy -->
      <div
        class="slider-item"
        style="background-image: url('images/naslovna-1.jpg')"
      >
        <div class="overlay"></div>
        <div class="container">
          <div
            class="row slider-text align-items-center"
            data-scrollax-parent="true"
          >
            <div
              class="col-md-6 col-sm-12 ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }"
            >
              <h1
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                Prirodna estetika, stručan pristup
              </h1>
              <p
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                Svaki plan pravimo individualno – jasno objašnjavamo opcije,
                očekivanja i oporavak. Naš cilj su prirodni, dugoročni rezultati
                uz brigu o sigurnosti pacijenta.
              </p>
              <p
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                <a href="#zakazite-termin" class="btn btn-primary px-4 py-3 mr-2"
                  >Zakažite pregled</a
                >
                <a
                  href="usluge.html"
                  class="btn btn-primary btn-outline-primary px-4 py-3"
                  >Pogledajte sve usluge</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>

      <!-- SLIDE 2 – blago prilagođen tekst -->
      <div
        class="slider-item"
        style="background-image: url('images/naslovna-2.jpg')"
      >
        <div class="overlay"></div>
        <div class="container">
          <div
            class="row slider-text align-items-center"
            data-scrollax-parent="true"
          >
            <div
              class="col-md-6 col-sm-12 ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }"
            >
              <h1
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                Estetska i rekonstruktivna hirurgija u Beogradu
              </h1>
              <p class="mb-4">
                Operacije kapaka, nosa, lica i tela planiraju se prema vašoj
                anatomiji i životnom stilu, uz fokus na prirodan rezultat i
                bezbedan oporavak.
              </p>
              <p>
                <a href="#zakazite-termin" class="btn btn-primary px-4 py-3"
                  >Zakažite pregled</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>

      <!-- SLIDE 3 – blago prilagođen tekst -->
      <div
        class="slider-item"
        style="background-image: url('images/naslovna-3.avif')"
      >
        <div class="overlay"></div>
        <div class="container">
          <div
            class="row slider-text align-items-center"
            data-scrollax-parent="true"
          >
            <div
              class="col-md-6 col-sm-12 ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }"
            >
              <h1
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                Bezbednost i poverenje na prvom mestu
              </h1>
              <p class="mb-4">
                Uz preciznu indikaciju za svaki zahvat i otvoren razgovor o
                očekivanjima, zajedno gradimo rezultat koji poštuje vaše crte
                lica i proporcije tela.
              </p>
              <p>
                <a href="#zakazite-termin" class="btn btn-primary px-4 py-3"
                  >Zakažite pregled</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ZAKAŽITE TERMIN – dodao sam id radi linka iz hero sekcije -->
    <section class="ftco-intro" id="zakazite-termin">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-md-9 color-3 p-4" style="margin: 0 auto">
            <h3 class="mb-2">Zakažite termin</h3>
            <form action="https://api.web3forms.com/submit" method="POST" class="appointment-form">
              <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
              <div class="row">
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="icon-user"></span></div>
                    <input
                      name="Ime"
                      type="text"
                      class="form-control"
                      id="appointment_name"
                      placeholder="Ime"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="icon-user"></span></div>
                    <input
                      name="Prezime"
                      type="text"
                      class="form-control"
                      id="appointment_name"
                      placeholder="Prezime"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon">
                      <span class="icon-paper-plane"></span>
                    </div>
                    <input
                      name="Email"
                      type="email"
                      class="form-control"
                      id="appointment_email"
                      placeholder="Email"
                    />
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon">
                      <span class="ion-ios-calendar"></span>
                    </div>
                    <input
                      name="Datum"
                      type="text"
                      class="form-control appointment_date"
                      placeholder="Datum"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="ion-ios-clock"></span></div>
                    <input
                      name="Vreme"
                      type="text"
                      class="form-control appointment_time"
                      placeholder="Vreme"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="icon-phone2"></span></div>
                    <input
                      name="Telefon"
                      type="text"
                      class="form-control"
                      id="phone"
                      placeholder="Telefon"
                    />
                  </div>
                </div>
              </div>

              <div class="form-group">
                <input
                  type="submit"
                  value="Zakažite termin"
                  class="btn btn-primary"
                />
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <!-- USLUGE / ŠTA RADIMO – tekst prilagođen novim kategorijama -->
    <section class="ftco-section ftco-services">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-2">USLUGE KOJE VAM NUDIMO</h2>
            <p>
              Crystal Medical pruža estetsku i rekonstruktivnu hirurgiju, nehirurške tretmane
              i korekciju ožiljaka. Plan svakog zahvata pravimo individualno, uz jasno
              objašnjena očekivanja i oporavak, sa ciljem prirodnih i dugoročnih rezultata.
            </p>
          </div>
        </div>
        <div class="row">
          <!-- HIRURGIJA LICA -->
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/face.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">HIRURGIJA LICA</h3>
                <p>
                  Rinoplastika, blefaroplastika, otoplastika, facelift i lipofiling –
                  zahvati kojima se koriguju proporcije lica uz poštovanje prirodnih crta
                  i funkcije.
                </p>
              </div>
            </div>
          </div>
          <!-- HIRURGIJA TELA -->
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/body.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">HIRURGIJA TELA</h3>
                <p>
                  Liposukcija, abdominoplastika, povećanje i podizanje grudi, korekcije
                  nakon velikog mršavljenja i ginekomastija – za ravnotežu proporcija tela.
                </p>
              </div>
            </div>
          </div>
          <!-- INTIMNA ESTETIKA -->
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/genital.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">INTIMNA ESTETIKA</h3>
                <p>
                  Labioplastika i funkcionalno–estetske korekcije intimne regije, uz diskretan
                  pristup i jasno definisane ciljeve tretmana.
                </p>
              </div>
            </div>
          </div>
          <!-- NEHIRURŠKI TRETMANI / DERMATOLOGIJA / REGENERACIJA -->
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/medical.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">NEHIRURŠKI TRETMANI</h3>
                <p>
                  Botoks, hijaluronski fileri, PRP, mezoterapija, Profhilo i niti, kao i
                  dermatološki tretmani ožiljaka i kožnih promena, uz terapije za
                  regeneraciju kože nakon opekotina i rana.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ABOUT / ZAŠTO MI – prilagođen tekst, bez promene layout-a -->
      <div class="container-wrap mt-5">
        <div class="row d-flex no-gutters">
          <div
            class="col-md-6 img"
            style="background-image: url(images/o-nama.jpg)"
          ></div>
          <div class="col-md-6 d-flex">
            <div class="about-wrap">
              <div
                class="heading-section heading-section-white mb-5 ftco-animate"
              >
                <h2 class="mb-2">
                  Prirodne proporcije i rezultat koji traje
                </h2>
                <p>
                  U Crystal Medical klinici svaka odluka o zahvatu zasniva se na detaljnoj
                  analizi anatomije, životnog stila i realnih očekivanja. Fokus je na
                  prirodnoj estetici, uz jasno objašnjene benefite, rizike i tok oporavka.
                </p>
              </div>
              <div class="list-services d-flex ftco-animate">
                <div
                  class="icon d-flex justify-content-center align-items-center"
                >
                  <span class="icon-check2"></span>
                </div>
                <div class="text">
                  <h3>STRUČAN TIM PREDVOĐEN DR MIHAILOM JAKŠIĆ</h3>
                  <p>
                    Tim čine specijalisti estetske i rekonstruktivne hirurgije i dermatologije
                    koji rade bez šablona i preterivanja – cilj je rezultat koji je usklađen
                    sa vašim licem i telom.
                  </p>
                </div>
              </div>
              <div class="list-services d-flex ftco-animate">
                <div
                  class="icon d-flex justify-content-center align-items-center"
                >
                  <span class="icon-check2"></span>
                </div>
                <div class="text">
                  <h3>REALNA OČEKIVANJA I JASAN PLAN OPORAVKA</h3>
                  <p>
                    Otvoreno govorimo o tome šta je zahvatom moguće postići, koji su rizici
                    i kako izgleda oporavak, kako biste doneli informisanu odluku.
                  </p>
                </div>
              </div>
              <div class="list-services d-flex ftco-animate">
                <div
                  class="icon d-flex justify-content-center align-items-center"
                >
                  <span class="icon-check2"></span>
                </div>
                <div class="text">
                  <h3>SAVREMENA TEHNOLOGIJA I PRECIZNA INDIKACIJA</h3>
                  <p>
                    Koristimo savremene tehnike i opremu, uz pažljiv izbor zahvata ili
                    tretmana, kako bismo postigli diskretne, ali dugotrajne rezultate.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- TIM, DOSTIGNUĆA, UTISCI, NEWSLETTER, GALERIJA, BLOG, QUOTE, KONTAKT, MAPA, FOOTER – ostaju uz minimalne izmene teksta ako želiš kasnije -->
    <!-- Sve ispod ostavljam kako jeste, jer si tražio da se ne dira dizajn niti sve menja. -->

    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-3">UPOZNAJTE NAŠ TIM STRUČNJAKA</h2>
            <p>
              Naši stručnjaci su visoko kvalifikovani i iskusni hirurzi i dermatolozi
              koji primenjuju savremene tehnike kako bi postigli pouzdane, prirodne rezultate.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-6 d-flex mb-sm-4 ftco-animate">
            <div class="staff">
              <div
                class="img mb-4"
                style="background-image: url(images/MJaksic.jpg)"
              ></div>
              <div class="info text-center">
                <h3><a href="teacher-single.html">Dr Mihaila Jakšić</a></h3>
                <span class="position">Specijalista plastične, rekonstruktivne i estetske hirurgije</span>
                <div class="text">
                  <p>
                    Vodi tim Crystal Medical klinike sa fokusom na prirodne rezultate i
                    individualni pristup svakom pacijentu.
                  </p>
                  <ul class="ftco-social">
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-facebook"></span></a>
                    </li>
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-instagram"></span></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 d-flex mb-sm-4 ftco-animate">
            <div class="staff">
              <div
                class="img mb-4"
                style="background-image: url(images/DjKrstic.jpg)"
              ></div>
              <div class="info text-center">
                <h3><a href="teacher-single.html">Dr Đorđe Krstić</a></h3>
                <span class="position">Dermatolog</span>
                <div class="text">
                  <p>
                    Specijalista dermatovenerologije sa fokusom na kožne promene, ožiljke
                    i dermoskopiju u sklopu estetskih tretmana.
                  </p>
                  <ul class="ftco-social">
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-facebook"></span></a>
                    </li>
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-instagram"></span></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <!-- ostatak tima po potrebi -->
        </div>
      </div>
    </section>

    <section
      class="ftco-section ftco-counter img"
      id="section-counter"
      style="background-image: url(images/dostignuca.jpg)"
      data-stellar-background-ratio="0.5"
    >
      <div class="container">
        <div class="row d-flex align-items-center">
          <div class="col-md-3 aside-stretch py-5">
            <div
              class="heading-section heading-section-white ftco-animate pr-md-4"
            >
              <h2 class="mb-3">DOSTIGNUĆA</h2>
              <p>
                Klinika gradi rezultate na stručnosti, iskustvu i visokom stepenu
                zadovoljstva pacijenata, uz stalno usavršavanje tima i procedura.
              </p>
            </div>
          </div>
          <div class="col-md-9 py-5 pl-md-5">
            <div class="row">
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="14">0</strong>
                    <span>USPEŠNE PROCEDURE</span>
                  </div>
                </div>
              </div>
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="4500">0</strong>
                    <span>TRETMANI</span>
                  </div>
                </div>
              </div>
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="4200">0</strong>
                    <span>ZADOVOLJNI PACIJENATI</span>
                  </div>
                </div>
              </div>
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="320">0</strong>
                    <span>SERTIFIKATI</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- OSTATAK STRANICE (testimonials, newsletter, galerija, blog, quote, kontakt, mapa, footer) ostaje kao u tvom kodu, bez funkcionalnih promena -->
    <!-- ... ovde ide isti kod koji već imaš (nisam ga krao da skratim odgovor) ... -->
    <!-- Po potrebi samo zameniš ovaj komentar svojim postojećim blokovima, oni ne moraju da se menjaju za SEO/home copy koji smo integrisali. -->

    <!-- (Možeš bukvalno zadržati sve od section testimony-section pa nadole iz tvog originalnog fajla.) -->

    <!-- Tvoj postojeći JS deo ostaje neizmenjen -->
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"
      integrity="sha512-uURl+ZXMBrF4AwGaWmEetzrd+J5/8NRkWAvJx5sbPSSuOb0bZLqf+tOzniObO00BjHa/dD7gub9oCGMLPQHtQA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    ></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/jquery.timepicker.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
