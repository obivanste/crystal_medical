<!DOCTYPE html>
<html lang="ru">
  <head>
    <title>Cristal Medical - Главная</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    
        <link rel="icon" href="images/logo_2.ico"  type="image/x-icon">

    <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.css" />

    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />

    <link rel="stylesheet" href="css/aos.css" />

    <link rel="stylesheet" href="css/ionicons.min.css" />

    <link rel="stylesheet" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="css/jquery.timepicker.css" />

    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/icomoon.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css"
      integrity="sha512-nNlU0WK2QfKsuEmdcTwkeh+lhGs6uyOxuUs+n+0oXSYDok5qy0EI0lt01ZynHq6+p/tbgpZ7P+yUb+r71wqdXg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>
  <body>
            <!--  
        <div id="errorModal" class="modal">
          <div class="modal-content">
            <span id="closeModal" class="close-button">&times;</span>
            <h1>ERROR 404</h1>
          </div>
        </div> -->
    <nav
      class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div class="container">
        <a class="navbar-brand" href="index-ru.php">
          <img id="logo" src="images/logo_1.png" alt="" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a href="index-ru.php" class="nav-link">ГЛАВНАЯ</a>
            </li>
            <li class="nav-item">
              <a href="o-nama-ru.html" class="nav-link">О НАС</a>
            </li>
            <li class="nav-item">
              <a href="usluge-ru.html" class="nav-link">УСЛУГИ</a>
            </li>
            <li class="nav-item">
              <a href="cenovnik-ru.html" class="nav-link">ЦЕНОВНИК</a>
            </li>
            <li class="nav-item">
              <a href="blog-ru.html" class="nav-link">БЛОГ</a>
            </li>
            <li class="nav-item">
              <a href="kontakt-ru.php" class="nav-link">КОНТАКТ</a>
            </li>
            <li class="nav-item">
              <a href="index.php" class="nav-link">
                <img
                  src="images/srpska-zastava.webp"
                  alt=""
                  style="height: 20px; width: 40px; border: 0.5px solid #154d32"
                />
              </a>
            </li>
            <li class="nav-item">
              <a href="index-uk.php" class="nav-link">
                <img
                  src="images/uk-zastava.png"
                  alt=""
                  style="height: 20px; width: 40px; border: 0.5px solid #154d32"
                />
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <section class="home-slider owl-carousel">
      <div
        class="slider-item"
        style="background-image: url('images/naslovna-1.jpg')"
      >
        <div class="overlay"></div>
        <div class="container">
          <div
            class="row slider-text align-items-center"
            data-scrollax-parent="true"
          >
            <div
              class="col-md-6 col-sm-12 ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }"
            >
              <h1
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                CRYSTAL MEDICAL
              </h1>
              <p
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                Наша клиника эстетической хирургии предлагает широкий спектр
                хирургических и нехирургических процедур, чтобы улучшить ваш
                внешний вид и повысить уверенность в себе.
              </p>
              <p
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                <a href="#" class="btn btn-primary px-4 py-3"
                  >ЗАПИСАТЬСЯ НА ПРИЕМ</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>

      <div
        class="slider-item"
        style="background-image: url('images/naslovna-2.jpg')"
      >
        <div class="overlay"></div>
        <div class="container">
          <div
            class="row slider-text align-items-center"
            data-scrollax-parent="true"
          >
            <div
              class="col-md-6 col-sm-12 ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }"
            >
              <h1
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                CRYSTAL MEDICAL
              </h1>
              <p class="mb-4">
                Мы предлагаем передовые процедуры, такие как операции на верхних
                и нижних веках, подтяжку лица и шеи, а также липосакцию
                различных частей тела.
              </p>
              <p>
                <a href="#" class="btn btn-primary px-4 py-3"
                  >ЗАПИСАТЬСЯ НА ПРИЕМ
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div
        class="slider-item"
        style="background-image: url('images/naslovna-3.avif')"
      >
        <div class="overlay"></div>
        <div class="container">
          <div
            class="row slider-text align-items-center"
            data-scrollax-parent="true"
          >
            <div
              class="col-md-6 col-sm-12 ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }"
            >
              <h1
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                CRYSTAL MEDICAL
              </h1>
              <p class="mb-4">
                Ваше удовлетворение и безопасность являются нашим приоритетом.
              </p>
              <p>
                <a href="#" class="btn btn-primary px-4 py-3"
                  >ЗАПИСАТЬСЯ НА ПРИЕМ</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-intro">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-md-9 color-3 p-4" style="margin: 0 auto">
            <h3 class="mb-2">ЗАПИСАТЬСЯ НА ПРИЕМ</h3>
            <form action="https://api.web3forms.com/submit" method="POST" class="appointment-form">
                <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
              <div class="row">
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="icon-user"></span></div>
                    <input
                      name="Ime"
                      type="text"
                      class="form-control"
                      id="appointment_name"
                      placeholder="Имя"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="icon-user"></span></div>
                    <input
                      name="Prezime"
                      type="text"
                      class="form-control"
                      id="appointment_name"
                      placeholder="Фамилия"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon">
                      <span class="icon-paper-plane"></span>
                    </div>
                    <input
                      name="Email"
                      type="text"
                      class="form-control"
                      id="appointment_email"
                      placeholder="Электронная почта"
                    />
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon">
                      <span class="ion-ios-calendar"></span>
                    </div>
                    <input
                      name="Datum"
                      type="text"
                      class="form-control appointment_date"
                      placeholder="Дата"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="ion-ios-clock"></span></div>
                    <input
                      name="Vreme"
                      type="text"
                      class="form-control appointment_time"
                      placeholder="Время"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="icon-phone2"></span></div>
                    <input
                      name="Telefon"
                      type="text"
                      class="form-control"
                      id="phone"
                      placeholder="Телефон"
                    />
                  </div>
                </div>
              </div>

              <div class="form-group">
                <input
                  type="submit"
                  value="Записаться на прием"
                  class="btn btn-primary"
                />
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-services">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-2">УСЛУГИ, КОТОРЫЕ МЫ ПРЕДЛАГАЕМ</h2>
            <p>
              Мы предлагаем широкий спектр услуг, включая лицевую хирургию,
              хирургию тела, генитальную хирургию, лечение ожогов и ран,
              коррекцию рубцов, нехирургические процедуры, такие как коррекция
              морщин и губ гиалуроновыми филлерами, ботокс, химический пилинг и
              омоложение различными техниками.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/face.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">ЛИЦЕВАЯ ХИРУРГИЯ</h3>
                <p>
                  Клиника предлагает операции на верхних и нижних веках,
                  удаление ксантелазм, операции на ушах и носу, подтяжку лица и
                  шеи, а также заполнение морщин жировой тканью.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/body.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">ХИРУРГИЯ ТЕЛА</h3>
                <p>
                  Мы предоставляем услуги по увеличению, уменьшению и подтяжке
                  груди, замене и удалению имплантатов, коррекции гинекомастии,
                  липофилингу грудной клетки, а также липосакции рук, живота,
                  спины, бедер и коленей.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/genital.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">ГЕНИТАЛЬНАЯ ХИРУРГИЯ</h3>
                <p>
                  Наша клиника занимается коррекцией малых и больших половых
                  губ, а также обрезанием.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/medical.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">НЕХИРУРГИЧЕСКИЕ ПРОЦЕДУРЫ</h3>
                <p>
                  Мы предоставляем нехирургические процедуры, такие как
                  коррекция морщин и губ гиалуроновыми филлерами, ботокс,
                  химический пилинг, биоревитализацию, PRP и Cellular Matrix,
                  мезотерапию и омоложение рук.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container-wrap mt-5">
        <div class="row d-flex no-gutters">
          <div
            class="col-md-6 img"
            style="background-image: url(images/o-nama.jpg)"
          ></div>
          <div class="col-md-6 d-flex">
            <div class="about-wrap">
              <div
                class="heading-section heading-section-white mb-5 ftco-animate"
              >
                <h2 class="mb-2">
                  Преобразите свой внешний вид с нашими высококвалифицированными
                  специалистами
                </h2>
                <p>
                  Crystal Medical предлагает широкий спектр услуг, включая
                  лицевую хирургию, хирургию тела, генитальную хирургию, лечение
                  ожогов и ран, коррекцию рубцов, а также нехирургические
                  процедуры, такие как коррекция морщин и губ гиалуроновыми
                  филлерами, ботокс, химический пилинг и омоложение различными
                  техниками.
                </p>
              </div>
              <div class="list-services d-flex ftco-animate">
                <div
                  class="icon d-flex justify-content-center align-items-center"
                >
                  <span class="icon-check2"></span>
                </div>
                <div class="text">
                  <h3>ИНДИВИДУАЛЬНЫЙ ПОДХОД К ПАЦИЕНТАМ</h3>
                  <p>
                    Мы подходим к каждому пациенту индивидуально, внимательно
                    выслушивая ваши пожелания и потребности, чтобы разработать
                    персонализированный план лечения, который поможет достичь
                    ваших целей.
                  </p>
                </div>
              </div>
              <div class="list-services d-flex ftco-animate">
                <div
                  class="icon d-flex justify-content-center align-items-center"
                >
                  <span class="icon-check2"></span>
                </div>
                <div class="text">
                  <h3>ОПЫТНАЯ КОМАНДА СПЕЦИАЛИСТОВ</h3>
                  <p>
                    Наша команда состоит из высококвалифицированных и опытных
                    хирургов и медицинского персонала, использующих самые
                    современные техники и технологии, чтобы предоставить вам
                    лучшие результаты.
                  </p>
                </div>
              </div>
              <div class="list-services d-flex ftco-animate">
                <div
                  class="icon d-flex justify-content-center align-items-center"
                >
                  <span class="icon-check2"></span>
                </div>
                <div class="text">
                  <h3>ШИРОКИЙ СПЕКТР УСЛУГ</h3>
                  <p>
                    Наша клиника предлагает комплексный спектр эстетических и
                    медицинских процедур, позволяя вам получить полное
                    обслуживание от начальной консультации до послеоперационного
                    ухода.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-3">ПОЗНАКОМЬТЕСЬ С НАШЕЙ КОМАНДОЙ СПЕЦИАЛИСТОВ</h2>
            <p>
              Наши специалисты - это высококвалифицированные и опытные хирурги,
              которые применяют самые современные техники и технологии, чтобы
              добиться лучших результатов для наших пациентов.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-6 d-flex mb-sm-4 ftco-animate">
            <div class="staff">
              <div
                class="img mb-4"
                style="background-image: url(images/MJaksic.jpg)"
              ></div>
              <div class="info text-center">
                <h3><a href="teacher-single.html">Др Михайла Якшич</a></h3>
                <span class="position">Хирург</span>
                <div class="text">
                  <p>Специалист по пластической, реконструктивной и эстетической хирургии</p>
                  <ul class="ftco-social">
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-facebook"></span></a>
                    </li>
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-instagram"></span></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 d-flex mb-sm-4 ftco-animate">
            <div class="staff">
              <div
                class="img mb-4"
                style="background-image: url(images/DjKrstic.jpg)"
              ></div>
              <div class="info text-center">
                <h3><a href="teacher-single.html">Др Джордже Крстич</a></h3>
                <span class="position">Дерматолог</span>
                <div class="text">
                  <p>Специалист по дерматологии и венерологии</p>
                  <ul class="ftco-social">
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-facebook"></span></a>
                    </li>
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-instagram"></span></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section
      class="ftco-section ftco-counter img"
      id="section-counter"
      style="background-image: url(images/dostignuca.jpg)"
      data-stellar-background-ratio="0.5"
    >
      <div class="container">
        <div class="row d-flex align-items-center">
          <div class="col-md-3 aside-stretch py-5">
            <div
              class="heading-section heading-section-white ftco-animate pr-md-4"
            >
              <h2 class="mb-3">ДОСТИЖЕНИЯ</h2>
              <p>
                Наша клиника гордится рядом достижений, включая более 100
                успешных процедур в первый месяц работы, 99% удовлетворенных
                пациентов и команду высококвалифицированных специалистов.
              </p>
            </div>
          </div>
          <div class="col-md-9 py-5 pl-md-5">
            <div class="row">
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="14">0</strong>
                    <span>УСПЕШНЫЕ ПРОЦЕДУРЫ</span>
                  </div>
                </div>
              </div>
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="4500">0</strong>
                    <span>ЛЕЧЕНИЯ</span>
                  </div>
                </div>
              </div>
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="4200">0</strong>
                    <span>УДОВЛЕТВОРЕННЫЕ ПАЦИЕНТЫ</span>
                  </div>
                </div>
              </div>
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="320">0</strong>
                    <span>СЕРТИФИКАТЫ</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section testimony-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-2">ОТЗЫВЫ НАШИХ УДОВЛЕТВОРЕННЫХ КЛИЕНТОВ</h2>
            <span class="subheading">Удовлетворенные клиенты </span>
          </div>
        </div>
        <div class="row justify-content-center ftco-animate">
          <div class="col-md-8">
            <div class="carousel-testimony owl-carousel ftco-owl">
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/sandra29_1.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      Я хочу выразить свою глубочайшую благодарность и похвалу доктору Михаиле, которая буквально изменила мою жизнь к лучшему. Весь мой жизнь меня тяготил врожденный птоз левого века, который серьезно повлиял на мою уверенность в себе. К этому добавился избыток кожи на верхних веках, что придавало мне усталый и сонный вид.
<br><br>
С того момента, как я переступила порог клиники, доктор Михаила встретила меня с теплотой, пониманием и профессионализмом. Её внимание к деталям и искренняя забота о пациентах сразу вселили в меня уверенность, что я в надежных руках. Операция, которую она провела, не только оправдала, но и значительно превзошла все мои ожидания. Теперь мой взгляд излучает уверенность.
                    </p>
                    <p class="name">Сандра, 29</p>
                    <span class="position"></span>
                  </div>
                </div>
              </div>
        <!--      <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/person_2.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      Даже всемогущий Пойнтинг не имеет контроля над слепыми
                      текстами. Это почти неорфографическая жизнь. Однажды,
                      однако, маленькая линия слепого текста по имени Lorem
                      Ipsum решила отправиться в далёкий мир Грамматики.
                    </p>
                    <p class="name">Деннис Грин</p>
                    <span class="position">Менеджер по маркетингу</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/person_3.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      Даже всемогущий Пойнтинг не имеет контроля над слепыми
                      текстами. Это почти неорфографическая жизнь. Однажды,
                      однако, маленькая линия слепого текста по имени Lorem
                      Ipsum решила отправиться в далёкий мир Грамматики.
                    </p>
                    <p class="name">Деннис Грин</p>
                    <span class="position">Менеджер по маркетингу</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/person_1.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      Даже всемогущий Пойнтинг не имеет контроля над слепыми
                      текстами. Это почти неорфографическая жизнь. Однажды,
                      однако, маленькая линия слепого текста по имени Lorem
                      Ipsum решила отправиться в далёкий мир Грамматики.
                    </p>
                    <p class="name">Деннис Грин</p>
                    <span class="position">Менеджер по маркетингу</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/person_1.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      Даже всемогущий Пойнтинг не имеет контроля над слепыми
                      текстами. Это почти неорфографическая жизнь. Однажды,
                      однако, маленькая линия слепого текста по имени Lorem
                      Ipsum решила отправиться в далёкий мир Грамматики.
                    </p>
                    <p class="name">Деннис Грин</p>
                    <span class="position">Менеджер по маркетингу</span>
                  </div>
                </div>
              </div>  -->
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section-parallax">
      <div class="parallax-img d-flex align-items-center">
        <div class="container">
          <div class="row d-flex justify-content-center">
            <div
              class="col-md-7 text-center heading-section heading-section-white ftco-animate"
            >
              <h2>ПОДПИШИТЕСЬ НА НАШ НОВОСТНОЙ БЮЛЛЕТЕНЬ</h2>
              <p>
                Подпишитесь на наш новостной бюллетень и будьте среди первых
                1000 пользователей, которые регулярно получают самую актуальную
                информацию о наших услугах, специальных предложениях и
                экспертных советах в области эстетической хирургии.
              </p>
              <div class="row d-flex justify-content-center mt-5">
                <div class="col-md-8">
                  <form action="https://api.web3forms.com/submit" method="POST" class="subscribe-form">
                      <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
                    <div class="form-group d-flex">
                      <input
                        name="Email"
                        type="text"
                        class="form-control"
                        placeholder="Ввeдите ваш адрес электронной почты"
                      />
                      <input
                        type="submit"
                        value="Pošaljite"
                        class="submit px-3"
                      />
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-gallery">
      <div class="container-wrap">
        <div class="row no-gutters">
          <div class="col-md-3 ftco-animate">
            <a
              href="#"
              class="gallery img d-flex align-items-center"
              style="background-image: url(images/cristal-clinic-1.webp)"
            >
              <div
                class="icon mb-4 d-flex align-items-center justify-content-center"
              >
                <span class="icon-search"></span>
              </div>
            </a>
          </div>
          <div class="col-md-3 ftco-animate">
            <a
              href="#"
              class="gallery img d-flex align-items-center"
              style="background-image: url(images/cristal-clinic-2.jpeg)"
            >
              <div
                class="icon mb-4 d-flex align-items-center justify-content-center"
              >
                <span class="icon-search"></span>
              </div>
            </a>
          </div>
          <div class="col-md-3 ftco-animate">
            <a
              href="#"
              class="gallery img d-flex align-items-center"
              style="background-image: url(images/cristal-clinic-3.jpg)"
            >
              <div
                class="icon mb-4 d-flex align-items-center justify-content-center"
              >
                <span class="icon-search"></span>
              </div>
            </a>
          </div>
          <div class="col-md-3 ftco-animate">
            <a
              href="#"
              class="gallery img d-flex align-items-center"
              style="background-image: url(images/cristal-clinic-4.jpg)"
            >
              <div
                class="icon mb-4 d-flex align-items-center justify-content-center"
              >
                <span class="icon-search"></span>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-2">НАШ БЛОГ</h2>
            <p>
              Откройте для себя последние тенденции и советы из мира
              эстетической хирургии в нашем блоге, где специалисты делятся
              полезной информацией о процедурах, восстановлении и достижении
              желаемых результатов.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a
                href="#"
                class="block-20"
                style="background-image: url('images/blog-1.avif')"
              >
              </a>
              <div class="text d-flex py-4">
                <div>
                  <h3 class="heading">
                    <a href="#"
                      >Как подготовиться к операции эстетической хирургии:
                      Руководство для пациентов
                    </a>
                  </h3>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-8 ftco-animate">
              <a
                href="#"
                class="block-20"
                style="background-image: url('images/visa.png')"
              >
              </a>
              <div class="text d-flex py-4">
                <div>
                  <h3 class="heading">
                    <a href="#" style="font-size: 20px; color: #000000; line-height: 1.5;"
                      >Оплата наших услуг возможна также с помощью карт Visa и Mastercard.</a
                    >
                  </h3>
                </div>
              </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-quote">
      <div class="container">
        <div class="row">
          <div class="col-md-6 pr-md-5 aside-stretch py-5 choose">
            <div
              class="heading-section heading-section-white mb-5 ftco-animate"
            >
              <h2 class="mb-2">CRYSTAL MEDICAL: ВАШ ПУТЬ К СОВЕРШЕНСТВУ</h2>
            </div>
            <div class="ftco-animate">
              <p>
                Crystal Medical - ведущая клиника эстетической хирургии,
                специализирующаяся на предоставлении самых современных процедур
                и вмешательств. Наша миссия - помочь вам достичь желаемого
                внешнего вида, используя новейшие техники и технологии. Мы
                гордимся нашей командой высококвалифицированных специалистов,
                которые преданы обеспечению высочайшего уровня ухода и
                достижению выдающихся результатов. В нашей клинике мы предлагаем
                широкий спектр услуг, включая лицевую хирургию, хирургию тела и
                нехирургические процедуры. С акцентом на безопасность и
                удовлетворение пациентов, Crystal Medical - ваше идеальное место
                для трансформации красоты.
              </p>
              <ul class="un-styled my-5">
                <li>
                  <span class="icon-check"></span>ОПЫТНАЯ КОМАНДА СПЕЦИАЛИСТОВ
                </li>
                <li>
                  <span class="icon-check"></span>ПЕРСОНАЛИЗИРОВАННЫЙ ПОДХОД
                </li>
                <li><span class="icon-check"></span>ШИРОКИЙ СПЕКТР УСЛУГ</li>
              </ul>
            </div>
          </div>
          <div class="col-md-6 py-5 pl-md-5">
            <div class="heading-section mb-5 ftco-animate">
              <h2 class="mb-2">СВЯЖИТЕСЬ С НАМИ</h2>
            </div>
            <form action="https://api.web3forms.com/submit" method="POST" class="ftco-animate">
                <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input name="Ime" type="text" class="form-control" placeholder="Имя" />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input
                      name="Prezime"
                      type="text"
                      class="form-control"
                      placeholder="Фамилия"
                    />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input
                      name="Email"
                      type="text"
                      class="form-control"
                      placeholder="Электронная почта"
                    />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input
                      name="Telefon"
                      type="text"
                      class="form-control"
                      placeholder="Телефон"
                    />
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <textarea
                      name="Poruka"
                      id=""
                      cols="30"
                      rows="7"
                      class="form-control"
                      placeholder="Сообщение"
                    ></textarea>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <input
                      type="submit"
                      value="Отправить"
                      class="btn btn-primary py-3 px-5"
                    />
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <iframe
      id="map"
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22638.926595259367!2d20.444034286144067!3d44.824298048493375!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a7bb7d5be7f87%3A0x89ee408d58f06edb!2sCrystal%20Clinic!5e0!3m2!1sen!2srs!4v1717963555214!5m2!1sen!2srs"
      style="border: 0"
      allowfullscreen=""
      loading="lazy"
      referrerpolicy="no-referrer-when-downgrade"
    ></iframe>

    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">
                <img
                  src="images/logo_1.png"
                  alt=""
                  style="height: 110px; width: 200px"
                />
              </h2>
              <p>
                Crystal Medical - ведущая клиника эстетической хирургии,
                посвятившая себя достижению выдающихся результатов с помощью
                самых современных техник и персонализированного ухода.
              </p>
            </div>
            <ul
              class="ftco-footer-social list-unstyled float-md-left float-lft"
            >
              <li class="ftco-animate">
                <a href="#"><span class="icon-instagram"></span></a>
              </li>
              <li class="ftco-animate">
                <a href="#"><span class="icon-facebook"></span></a>
              </li>
            </ul>
          </div>
          <div class="col-md-2">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">ССЫЛКИ</h2>
              <ul class="list-unstyled">
                <li>
                  <a href="index-ru.php" class="py-2 d-block">Главная </a>
                </li>
                <li>
                  <a href="o-nama-ru.html" class="py-2 d-block">О нас </a>
                </li>
                <li>
                  <a href="usluge-ru.html" class="py-2 d-block">Услуги </a>
                </li>
                <li>
                  <a href="cenovnik-ru.html" class="py-2 d-block">Ценовник </a>
                </li>
                <li><a href="blog-ru.html" class="py-2 d-block">Блог</a></li>
                <li>
                  <a href="kontakt-ru.php" class="py-2 d-block">Контакт </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 pr-md-4">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">БЛОГОВЫЕ ЗАПИСИ</h2>
              <div class="block-21 mb-4 d-flex">
                <a
                  class="blog-img mr-4"
                  style="background-image: url(images/blog-1.avif)"
                ></a>
                <div class="text">
                  <h3 class="heading">
                    <a href="#"
                      >Как подготовиться к операции эстетической хирургии:
                      Руководство для пациентов
                    </a>
                  </h3>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">КОНТАКТЫ</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li>
                    <a href="https://maps.app.goo.gl/viXz25ywssE4kNAd8">
                      <span class="icon icon-map-marker"></span
                      ><span class="text"
                        >Улица Войислава Илича 137, 2-й этаж, Звездара Белград
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href="tel:+381 60 190 9309"
                      ><span class="icon icon-phone"></span
                      ><span class="text">+381 60 190 9309</span></a
                    >
                    <a href="tel:+381 60 190 9309"
                      ><span class="icon icon-phone" style="color:transparent;"></span
                      ><span class="text">+381 11 764 7210</span></a
                    >
                  </li>
                  <li>
                    <a href="mailto:office@crystalclinic.rs"
                      ><span class="icon icon-envelope"></span
                      ><span class="text">office@crystalmedical.rs</span></a
                    >
                    <a href="mailto:info@crystalmedical.rs"
                      ><span class="icon icon-envelope" style="color:transparent;"></span
                      ><span class="text">info@crystalmedical.rs</span></a
                    >
                    <a href="mailto:drmihaila@crystalmedical.rs"
                      ><span class="icon icon-envelope" style="color:transparent;"></span
                      ><span class="text">drmihaila@crystalmedical.rs</span></a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
            <p>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              &copy;
              <script>
                document.write(new Date().getFullYear());
              </script>
              Все права защищены |
              <a href="https://apisdevelopment.rs" target="_blank"
                >Apis Development</a
              >
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
        </div>
      </div>
    </footer>

    <!-- loader -->
    <div id="preloader">
      <div class="logo">
        <img src="images/logo_1.png" alt="Logo" />
      </div>
    </div>

    <!-- Modal -->
    <div
      class="modal fade"
      id="modalRequest"
      tabindex="-1"
      role="dialog"
      aria-labelledby="modalRequestLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalRequestLabel">
              Записаться на приём
            </h5>
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="https://api.web3forms.com/submit" method="POST">
                <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
              <div class="form-group">
                <!-- <label for="appointment_name" class="text-black">Full Name</label> -->
                <input
                  name="Ime_i_prezime"
                  type="text"
                  class="form-control"
                  id="appointment_name"
                  placeholder="Полное имя"
                />
              </div>
              <div class="form-group">
                <!-- <label for="appointment_email" class="text-black">Email</label> -->
                <input
                  name="Email"
                  type="email"
                  class="form-control"
                  id="appointment_email"
                  placeholder="Электронная почта"
                />
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <!-- <label for="appointment_date" class="text-black">Date</label> -->
                    <input
                      name="Datum"
                      type="text"
                      class="form-control appointment_date"
                      placeholder="Дата"
                    />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <!-- <label for="appointment_time" class="text-black">Time</label> -->
                    <input
                      name="Vreme"
                      type="text"
                      class="form-control appointment_time"
                      placeholder="Время"
                    />
                  </div>
                </div>
              </div>

              <div class="form-group">
                <!-- <label for="appointment_message" class="text-black">Message</label> -->
                <textarea
                  name="Poruka"
                  id="appointment_message"
                  class="form-control"
                  cols="30"
                  rows="10"
                  placeholder="Сообщение"
                ></textarea>
              </div>
              <div class="form-group">
                <input
                  type="submit"
                  value="Make an Appointment"
                  class="btn btn-primary"
                />
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"
      integrity="sha512-uURl+ZXMBrF4AwGaWmEetzrd+J5/8NRkWAvJx5sbPSSuOb0bZLqf+tOzniObO00BjHa/dD7gub9oCGMLPQHtQA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    ></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/jquery.timepicker.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
