<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Cristal Medical - Home</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    
        <link rel="icon" href="images/logo_2.ico"  type="image/x-icon">

    <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.css" />

    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />

    <link rel="stylesheet" href="css/aos.css" />

    <link rel="stylesheet" href="css/ionicons.min.css" />

    <link rel="stylesheet" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="css/jquery.timepicker.css" />

    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/icomoon.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css"
      integrity="sha512-nNlU0WK2QfKsuEmdcTwkeh+lhGs6uyOxuUs+n+0oXSYDok5qy0EI0lt01ZynHq6+p/tbgpZ7P+yUb+r71wqdXg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
  </head>
  <body>
            <!-- 
        <div id="errorModal" class="modal">
          <div class="modal-content">
            <span id="closeModal" class="close-button">&times;</span>
            <h1>ERROR 404</h1>
          </div>
        </div> -->
    <nav
      class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div class="container">
        <a class="navbar-brand" href="index-uk.php">
          <img id="logo" src="images/logo_1.png" alt="" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a href="index-uk.php" class="nav-link">HOME</a>
            </li>
            <li class="nav-item">
              <a href="about-us.html" class="nav-link">ABOUT US</a>
            </li>
            <li class="nav-item">
              <a href="services.html" class="nav-link">SERVICES</a>
            </li>
            <li class="nav-item">
              <a href="pricing.html" class="nav-link">PRICELIST</a>
            </li>
            <li class="nav-item">
              <a href="blog-uk.html" class="nav-link">BLOG</a>
            </li>
            <li class="nav-item">
              <a href="contact.php" class="nav-link">CONTACT</a>
            </li>

            <li class="nav-item">
              <a href="index.php" class="nav-link">
                <img
                  src="images/srpska-zastava.webp"
                  alt=""
                  style="height: 20px; width: 40px; border: 0.5px solid #154d32"
                />
              </a>
            </li>
            <li class="nav-item">
              <a href="index-ru.php" class="nav-link">
                <img
                  src="images/ruski-jezik.png"
                  alt=""
                  style="height: 20px; width: 40px; border: 0.5px solid #154d32"
                />
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <section class="home-slider owl-carousel">
      <div
        class="slider-item"
        style="background-image: url('images/naslovna-1.jpg')"
      >
        <div class="overlay"></div>
        <div class="container">
          <div
            class="row slider-text align-items-center"
            data-scrollax-parent="true"
          >
            <div
              class="col-md-6 col-sm-12 ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }"
            >
              <h1
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                CRYSTAL MEDICAL
              </h1>
              <p
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                Our aesthetic surgery clinic offers a wide range of surgical and
                non-surgical treatments to enhance your appearance and
                confidence.
              </p>
              <p
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                <a href="#" class="btn btn-primary px-4 py-3"
                  >BOOK AN APPOINTMENT</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>

      <div
        class="slider-item"
        style="background-image: url('images/naslovna-2.jpg')"
      >
        <div class="overlay"></div>
        <div class="container">
          <div
            class="row slider-text align-items-center"
            data-scrollax-parent="true"
          >
            <div
              class="col-md-6 col-sm-12 ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }"
            >
              <h1
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                CRYSTAL MEDICAL
              </h1>
              <p class="mb-4">
                We provide top-notch procedures such as upper and lower eyelid
                surgeries, facelifts, neck lifts, and liposuction for various
                body parts.
              </p>
              <p>
                <a href="#" class="btn btn-primary px-4 py-3"
                  >BOOK AN APPOINTMENT</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>

      <div
        class="slider-item"
        style="background-image: url('images/naslovna-3.avif')"
      >
        <div class="overlay"></div>
        <div class="container">
          <div
            class="row slider-text align-items-center"
            data-scrollax-parent="true"
          >
            <div
              class="col-md-6 col-sm-12 ftco-animate"
              data-scrollax=" properties: { translateY: '70%' }"
            >
              <h1
                class="mb-4"
                data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"
              >
                CRYSTAL MEDICAL
              </h1>
              <p class="mb-4">
                Your satisfaction and safety are our top priorities.
              </p>
              <p>
                <a href="#" class="btn btn-primary px-4 py-3"
                  >BOOK AN APPOINTMENT</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-intro">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-md-9 color-3 p-4" style="margin: 0 auto">
            <h3 class="mb-2">Book an Appointment</h3>
            <form action="https://api.web3forms.com/submit" method="POST" class="appointment-form">
                <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
              <div class="row">
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="icon-user"></span></div>
                    <input
                      name="Ime"
                      type="text"
                      class="form-control"
                      id="appointment_name"
                      placeholder="First name"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="icon-user"></span></div>
                    <input
                      name="Prezime"
                      type="text"
                      class="form-control"
                      id="appointment_name"
                      placeholder="Surname"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon">
                      <span class="icon-paper-plane"></span>
                    </div>
                    <input
                      name="Email"
                      type="Email"
                      class="form-control"
                      id="appointment_email"
                      placeholder="Email"
                    />
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon">
                      <span class="ion-ios-calendar"></span>
                    </div>
                    <input
                      name="Datum"
                      type="text"
                      class="form-control appointment_date"
                      placeholder="Date"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="ion-ios-clock"></span></div>
                    <input
                      name="Vreme"
                      type="text"
                      class="form-control appointment_time"
                      placeholder="Time"
                    />
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="form-group">
                    <div class="icon"><span class="icon-phone2"></span></div>
                    <input
                      name="Telefon"
                      type="text"
                      class="form-control"
                      id="phone"
                      placeholder="Phone"
                    />
                  </div>
                </div>
              </div>

              <div class="form-group">
                <input
                  type="submit"
                  value="Book an Appointment "
                  class="btn btn-primary"
                />
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-services">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-2">SERVICES WE OFFER</h2>
            <p>
              We offer a wide range of services including facial and body
              surgeries, genital surgery, burn and wound treatment, scar
              correction, and non-surgical treatments like wrinkle and lip
              correction with hyaluronic fillers, Botox, chemical peels, and
              rejuvenation with various techniques.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/face.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">FACIAL SURGERY</h3>
                <p>
                  The clinic offers surgeries such as upper and lower eyelid
                  surgeries, removal of xanthelasma, ear and nose surgeries,
                  facelifts, and facial fat tissue filling.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/body.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">BODY SURGERY</h3>
                <p>
                  We provide breast augmentation, reduction, and lift services,
                  implant replacement and removal, gynecomastia correction,
                  pectoral lipofilling, and liposuction of arms, abdomen, back,
                  thighs, and knees.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/genital.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">GENITAL SURGERY</h3>
                <p>
                  Our clinic specializes in labiaplasty, hymenoplasty, and
                  circumcision.
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-3 d-flex align-self-stretch ftco-animate">
            <div class="media block-6 services d-block text-center">
              <div
                class="icon d-flex justify-content-center align-items-center"
              >
                <img src="images/medical.png" style="width:50px; height:50px;">
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">NON-SURGICAL TREATMENTS</h3>
                <p>
                  We offer non-surgical treatments like wrinkle and lip
                  correction with hyaluronic fillers, Botox, chemical peels,
                  biorevitalization, PRP and Cellular Matrix, mesotherapy, and
                  hand rejuvenation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container-wrap mt-5">
        <div class="row d-flex no-gutters">
          <div
            class="col-md-6 img"
            style="background-image: url(images/o-nama.jpg)"
          ></div>
          <div class="col-md-6 d-flex">
            <div class="about-wrap">
              <div
                class="heading-section heading-section-white mb-5 ftco-animate"
              >
                <h2 class="mb-2">
                  Transform your appearance with our expert team
                </h2>
                <p>
                  Crystal Medical offers a wide range of services including
                  facial and body surgery, genital surgery, burn and wound
                  treatment, scar correction, and non-surgical treatments like
                  wrinkle and lip correction with hyaluronic fillers, Botox,
                  chemical peels, and rejuvenation with various techniques.
                </p>
              </div>
              <div class="list-services d-flex ftco-animate">
                <div
                  class="icon d-flex justify-content-center align-items-center"
                >
                  <span class="icon-check2"></span>
                </div>
                <div class="text">
                  <h3>INDIVIDUAL APPROACH TO PATIENTS</h3>
                  <p>
                    We approach each patient individually, carefully listening
                    to your desires and needs to develop a personalized
                    treatment plan that will achieve your goals.
                  </p>
                </div>
              </div>
              <div class="list-services d-flex ftco-animate">
                <div
                  class="icon d-flex justify-content-center align-items-center"
                >
                  <span class="icon-check2"></span>
                </div>
                <div class="text">
                  <h3>EXPERIENCED TEAM OF EXPERTS</h3>
                  <p>
                    Our team consists of highly qualified and experienced
                    surgeons and medical staff who use state-of-the-art
                    techniques and technologies to provide you with the best
                    results.
                  </p>
                </div>
              </div>
              <div class="list-services d-flex ftco-animate">
                <div
                  class="icon d-flex justify-content-center align-items-center"
                >
                  <span class="icon-check2"></span>
                </div>
                <div class="text">
                  <h3>WIDE RANGE OF SERVICES</h3>
                  <p>
                    Our clinic offers a comprehensive range of aesthetic and
                    medical treatments, allowing you to receive complete service
                    from initial consultation to post-operative care all in one
                    place.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-3">MEET OUR TEAM OF EXPERTS</h2>
            <p>
              Our experts are highly qualified and experienced surgeons who
              apply the latest techniques and technologies to achieve the best
              results for our patients.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-3 col-md-6 d-flex mb-sm-4 ftco-animate">
            <div class="staff">
              <div
                class="img mb-4"
                style="background-image: url(images/MJaksic.jpg)"
              ></div>
              <div class="info text-center">
                <h3><a href="teacher-single.html">Dr Mihaila Jakšić</a></h3>
                <span class="position">Surgeon</span>
                <div class="text">
                  <p>
                    Specialist in Plastic, Reconstructive, and Aesthetic Surgery
                  </p>
                  <ul class="ftco-social">
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-facebook"></span></a>
                    </li>
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-instagram"></span></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 d-flex mb-sm-4 ftco-animate">
            <div class="staff">
              <div
                class="img mb-4"
                style="background-image: url(images/DjKrstic.jpg)"
              ></div>
              <div class="info text-center">
                <h3><a href="teacher-single.html">Dr Đorđe Krstić</a></h3>
                <span class="position">Dermatologist</span>
                <div class="text">
                  <p>
                    Specialist in Dermatology and Venereology
                  </p>
                  <ul class="ftco-social">
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-facebook"></span></a>
                    </li>
                    <li class="ftco-animate">
                      <a href="#"><span class="icon-instagram"></span></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section
      class="ftco-section ftco-counter img"
      id="section-counter"
      style="background-image: url(images/dostignuca.jpg)"
      data-stellar-background-ratio="0.5"
    >
      <div class="container">
        <div class="row d-flex align-items-center">
          <div class="col-md-3 aside-stretch py-5">
            <div
              class="heading-section heading-section-white ftco-animate pr-md-4"
            >
              <h2 class="mb-3">ACHIEVEMENTS</h2>
              <p>
                Our clinic boasts a range of achievements, including over 100
                successful procedures in the first month of operation, 99%
                satisfied patients, and a team of highly qualified experts.
              </p>
            </div>
          </div>
          <div class="col-md-9 py-5 pl-md-5">
            <div class="row">
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="14">0</strong>
                    <span>SUCCESSFUL PROCEDURES </span>
                  </div>
                </div>
              </div>
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="4500">0</strong>
                    <span>TREATMENTS</span>
                  </div>
                </div>
              </div>
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="4200">0</strong>
                    <span>SATISFIED PATIENTS</span>
                  </div>
                </div>
              </div>
              <div
                class="col-md-3 d-flex justify-content-center counter-wrap ftco-animate"
              >
                <div class="block-18">
                  <div class="text">
                    <strong class="number" data-number="320">0</strong>
                    <span>CERTIFICATIONS</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section testimony-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-2">IMPRESSIONS OF OUR SATISFIED CLIENTS</h2>
            <span class="subheading">Satisfied clients</span>
          </div>
        </div>
        <div class="row justify-content-center ftco-animate">
          <div class="col-md-8">
            <div class="carousel-testimony owl-carousel ftco-owl">
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/sandra29_1.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      I want to express my deepest gratitude and praise to Dr. Mihaila, who literally changed my life for the better. I have been burdened my entire life by a congenital ptosis of my left eyelid, which seriously affected my self-confidence. This was further compounded by excess skin on my upper eyelids, giving me a tired and sleepy appearance. <br><br>

From the moment I stepped into the clinic, Dr. Mihaila welcomed me with warmth, understanding, and professionalism. Her attention to detail and genuine care for her patients immediately gave me confidence that I was in the right hands. The surgery she performed not only met but far exceeded all my expectations. Now my gaze radiates confidence.
                    </p>
                    <p class="name">Sandra, 29</p>
                    <span class="position"></span>
                  </div>
                </div>
              </div>
        <!--      <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/person_2.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      Far far away, behind the word mountains, far from the
                      countries Vokalia and Consonantia, there live the blind
                      texts.
                    </p>
                    <p class="name">Dennis Green</p>
                    <span class="position">Interface Designer</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/person_3.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      Far far away, behind the word mountains, far from the
                      countries Vokalia and Consonantia, there live the blind
                      texts.
                    </p>
                    <p class="name">Dennis Green</p>
                    <span class="position">UI Designer</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/person_1.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      Far far away, behind the word mountains, far from the
                      countries Vokalia and Consonantia, there live the blind
                      texts.
                    </p>
                    <p class="name">Dennis Green</p>
                    <span class="position">Web Developer</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap p-4 pb-5">
                  <div
                    class="user-img mb-5"
                    style="background-image: url(images/person_1.jpg)"
                  >
                    <span
                      class="quote d-flex align-items-center justify-content-center"
                    >
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text text-center">
                    <p class="mb-5">
                      Far far away, behind the word mountains, far from the
                      countries Vokalia and Consonantia, there live the blind
                      texts.
                    </p>
                    <p class="name">Dennis Green</p>
                    <span class="position">System Analytics</span>
                  </div>
                </div>
              </div>  -->
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section-parallax">
      <div class="parallax-img d-flex align-items-center">
        <div class="container">
          <div class="row d-flex justify-content-center">
            <div
              class="col-md-7 text-center heading-section heading-section-white ftco-animate"
            >
              <h2>SIGN UP FOR OUR NEWSLETTER</h2>
              <p>
                Sign up for our newsletter and be among the first 1000 users to
                regularly receive the latest information about our services,
                special offers, and expert advice in the field of aesthetic
                surgery.
              </p>
              <div class="row d-flex justify-content-center mt-5">
                <div class="col-md-8">
                  <form action="https://api.web3forms.com/submit" method="POST" class="subscribe-form">
                      <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
                    <div class="form-group d-flex">
                      <input
                        name="Email"
                        type="text"
                        class="form-control"
                        placeholder="Enter your email"
                      />
                      <input
                        type="submit"
                        value="Subscribe"
                        class="submit px-3"
                      />
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-gallery">
      <div class="container-wrap">
        <div class="row no-gutters">
          <div class="col-md-3 ftco-animate">
            <a
              href="#"
              class="gallery img d-flex align-items-center"
              style="background-image: url(images/cristal-clinic-1.webp)"
            >
              <div
                class="icon mb-4 d-flex align-items-center justify-content-center"
              >
                <span class="icon-search"></span>
              </div>
            </a>
          </div>
          <div class="col-md-3 ftco-animate">
            <a
              href="#"
              class="gallery img d-flex align-items-center"
              style="background-image: url(images/cristal-clinic-2.jpeg)"
            >
              <div
                class="icon mb-4 d-flex align-items-center justify-content-center"
              >
                <span class="icon-search"></span>
              </div>
            </a>
          </div>
          <div class="col-md-3 ftco-animate">
            <a
              href="#"
              class="gallery img d-flex align-items-center"
              style="background-image: url(images/cristal-clinic-3.jpg)"
            >
              <div
                class="icon mb-4 d-flex align-items-center justify-content-center"
              >
                <span class="icon-search"></span>
              </div>
            </a>
          </div>
          <div class="col-md-3 ftco-animate">
            <a
              href="#"
              class="gallery img d-flex align-items-center"
              style="background-image: url(images/cristal-clinic-4.jpg)"
            >
              <div
                class="icon mb-4 d-flex align-items-center justify-content-center"
              >
                <span class="icon-search"></span>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 text-center heading-section ftco-animate">
            <h2 class="mb-2">OUR BLOG</h2>
            <p>
              Discover the latest trends and tips in the world of aesthetic
              surgery in our blog section, where experts share valuable
              information about treatments, recovery, and achieving desired
              results.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a
                href="#"
                class="block-20"
                style="background-image: url('images/blog-1.avif')"
              >
              </a>
              <div class="text d-flex py-4">
                <div>
                  <h3 class="heading">
                    <a href="#"
                      >How to Prepare for Aesthetic Surgery: Patient's Guide</a
                    >
                  </h3>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-8 ftco-animate">
              <a
                href="#"
                class="block-20"
                style="background-image: url('images/visa.png')"
              >
              </a>
              <div class="text d-flex py-4">
                <div>
                  <h3 class="heading">
                    <a href="#" style="font-size: 20px; color: #000000; line-height: 1.5;"
                      >Payment for our professional services is also possible via Visa and Mastercard.</a
                    >
                  </h3>
                </div>
              </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-quote">
      <div class="container">
        <div class="row">
          <div class="col-md-6 pr-md-5 aside-stretch py-5 choose">
            <div
              class="heading-section heading-section-white mb-5 ftco-animate"
            >
              <h2 class="mb-2">CRYSTAL MEDICAL: YOUR PATH TO PERFECTION</h2>
            </div>
            <div class="ftco-animate">
              <p>
                Crystal Medical is a leading aesthetic surgery clinic,
                specializing in providing the most advanced treatments and
                procedures. Our mission is to help you achieve your desired
                appearance using state-of-the-art techniques and technologies.
                We are proud of our team of highly qualified experts who are
                dedicated to providing top-notch care and achieving outstanding
                results. In our clinic, we offer a wide range of services,
                including facial and body surgery, as well as non-surgical
                treatments. With a focus on patient safety and satisfaction,
                Crystal Medical is your ideal place for beauty transformation.
              </p>
              <ul class="un-styled my-5">
                <li>
                  <span class="icon-check"></span>EXPERIENCED TEAM OF EXPERTS
                </li>
                <li><span class="icon-check"></span>PERSONALIZED APPROACH</li>
                <li><span class="icon-check"></span>WIDE RANGE OF SERVICES</li>
              </ul>
            </div>
          </div>
          <div class="col-md-6 py-5 pl-md-5">
            <div class="heading-section mb-5 ftco-animate">
              <h2 class="mb-2">CONTACT US</h2>
            </div>
            <form action="https://api.web3forms.com/submit" method="POST" class="ftco-animate">
                <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input
                      name="Ime"
                      type="text"
                      class="form-control"
                      placeholder="First name"
                    />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input
                      name="Prezime"
                      type="text"
                      class="form-control"
                      placeholder="Surname"
                    />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input
                      name="Email"
                      type="text"
                      class="form-control"
                      placeholder="Email adress"
                    />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <input
                      name="Telefon"
                      type="text"
                      class="form-control"
                      placeholder="Phone"
                    />
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <textarea
                      name="Poruka"
                      id=""
                      cols="30"
                      rows="7"
                      class="form-control"
                      placeholder="Message"
                    ></textarea>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <input
                      type="submit"
                      value="Send"
                      class="btn btn-primary py-3 px-5"
                    />
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <iframe
      id="map"
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22638.926595259367!2d20.444034286144067!3d44.824298048493375!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a7bb7d5be7f87%3A0x89ee408d58f06edb!2sCrystal%20Clinic!5e0!3m2!1sen!2srs!4v1717963555214!5m2!1sen!2srs"
      style="border: 0"
      allowfullscreen=""
      loading="lazy"
      referrerpolicy="no-referrer-when-downgrade"
    ></iframe>

    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">
                <img
                  src="images/logo_1.png"
                  alt=""
                  style="height: 110px; width: 200px"
                />
              </h2>
              <p>
                Crystal Medical is a leading aesthetic surgery clinic dedicated
                to achieving excellent results through state-of-the-art
                techniques and personalized care.
              </p>
            </div>
            <ul
              class="ftco-footer-social list-unstyled float-md-left float-lft"
            >
              <li class="ftco-animate">
                <a href="#"><span class="icon-instagram"></span></a>
              </li>
              <li class="ftco-animate">
                <a href="#"><span class="icon-facebook"></span></a>
              </li>
            </ul>
          </div>
          <div class="col-md-2">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">LINKS</h2>
              <ul class="list-unstyled">
                <li>
                  <a href="index-uk.php" class="py-2 d-block">Home</a>
                </li>
                <li>
                  <a href="about-us.html" class="py-2 d-block">About us</a>
                </li>
                <li>
                  <a href="services.html" class="py-2 d-block">Services</a>
                </li>
                <li>
                  <a href="pricing.html" class="py-2 d-block">Pricelist</a>
                </li>
                <li><a href="blog-uk.html" class="py-2 d-block">Blog</a></li>
                <li><a href="contact.php" class="py-2 d-block">Contact</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 pr-md-4">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">BLOG POSTS</h2>
              <div class="block-21 mb-4 d-flex">
                <a
                  class="blog-img mr-4"
                  style="background-image: url(images/blog-1.avif)"
                ></a>
                <div class="text">
                  <h3 class="heading">
                    <a href="#"
                      >How to Prepare for Aesthetic Surgery: Patient's Guide
                    </a>
                  </h3>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">CONTACT</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li>
                    <a href="https://maps.app.goo.gl/viXz25ywssE4kNAd8">
                      <span class="icon icon-map-marker"></span
                      ><span class="text"
                        >Street Vojislava Ilića 137, Sprat 2, Zvezdara Belgrade</span
                      >
                    </a>
                  </li>
                  <li>
                    <a href="tel:+381 60 190 9309"
                      ><span class="icon icon-phone"></span
                      ><span class="text">+381 60 190 9309</span></a
                    >
                    <a href="tel:+381 60 190 9309"
                      ><span class="icon icon-phone" style="color:transparent;"></span
                      ><span class="text">+381 11 764 7210</span></a
                    >
                  </li>
                  <li>
                    <a href="mailto:office@crystalclinic.rs"
                      ><span class="icon icon-envelope"></span
                      ><span class="text">office@crystalmedical.rs</span></a
                    >
                    <a href="mailto:info@crystalmedical.rs"
                      ><span class="icon icon-envelope" style="color:transparent;"></span
                      ><span class="text">info@crystalmedical.rs</span></a
                    >
                    <a href="mailto:drmihaila@crystalmedical.rs"
                      ><span class="icon icon-envelope" style="color:transparent;"></span
                      ><span class="text">drmihaila@crystalmedical.rs</span></a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
            <p>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              &copy;
              <script>
                document.write(new Date().getFullYear());
              </script>
              All rights reserved |
              <a href="https://apisdevelopment.rs" target="_blank"
                >Apis Development</a
              >
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
        </div>
      </div>
    </footer>

    <!-- loader -->
    <div id="preloader">
      <div class="logo">
        <img src="images/logo_1.png" alt="Logo" />
      </div>
    </div>

    <!-- Modal -->
    <div
      class="modal fade"
      id="modalRequest"
      tabindex="-1"
      role="dialog"
      aria-labelledby="modalRequestLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalRequestLabel">
              Make an Appointment
            </h5>
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="https://api.web3forms.com/submit" method="POST">
                <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
              <div class="form-group">
                <!-- <label for="appointment_name" class="text-black">Full Name</label> -->
                <input
                  name="Ime_i_prezime"
                  type="text"
                  class="form-control"
                  id="appointment_name"
                  placeholder="Full Name"
                />
              </div>
              <div class="form-group">
                <!-- <label for="appointment_email" class="text-black">Email</label> -->
                <input
                  name="Email"
                  type="text"
                  class="form-control"
                  id="appointment_email"
                  placeholder="Email"
                />
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <!-- <label for="appointment_date" class="text-black">Date</label> -->
                    <input
                      name="Datum"
                      type="text"
                      class="form-control appointment_date"
                      placeholder="Date"
                    />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <!-- <label for="appointment_time" class="text-black">Time</label> -->
                    <input
                      name="Vreme"
                      type="text"
                      class="form-control appointment_time"
                      placeholder="Time"
                    />
                  </div>
                </div>
              </div>

              <div class="form-group">
                <!-- <label for="appointment_message" class="text-black">Message</label> -->
                <textarea
                  name="Poruka"
                  id="appointment_message"
                  class="form-control"
                  cols="30"
                  rows="10"
                  placeholder="Message"
                ></textarea>
              </div>
              <div class="form-group">
                <input
                  type="submit"
                  value="Make an Appointment"
                  class="btn btn-primary"
                />
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"
      integrity="sha512-uURl+ZXMBrF4AwGaWmEetzrd+J5/8NRkWAvJx5sbPSSuOb0bZLqf+tOzniObO00BjHa/dD7gub9oCGMLPQHtQA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    ></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/jquery.timepicker.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
