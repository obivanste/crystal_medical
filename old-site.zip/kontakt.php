<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Crystal Medical - Kontakt</title>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    
        <link rel="icon" href="images/logo_2.ico"  type="image/x-icon">

    <link
      href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css" />
    <link rel="stylesheet" href="css/animate.css" />

    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />

    <link rel="stylesheet" href="css/aos.css" />

    <link rel="stylesheet" href="css/ionicons.min.css" />

    <link rel="stylesheet" href="css/bootstrap-datepicker.css" />
    <link rel="stylesheet" href="css/jquery.timepicker.css" />

    <link rel="stylesheet" href="css/flaticon.css" />
    <link rel="stylesheet" href="css/icomoon.css" />
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <nav
      class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light"
      id="ftco-navbar"
    >
      <div class="container">
        <a class="navbar-brand" href="index.php">
          <img id="logo" src="images/logo_1.png" alt="" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#ftco-nav"
          aria-controls="ftco-nav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a href="index.php" class="nav-link">POČETNA</a>
            </li>
            <li class="nav-item">
              <a href="o-nama.html" class="nav-link">O NAMA</a>
            </li>
            <li class="nav-item active">
              <a href="usluge.html" class="nav-link">USLUGE</a>
            </li>
            <li class="nav-item">
              <a href="cenovnik.html" class="nav-link">CENOVNIK</a>
            </li>

            <li class="nav-item">
              <a href="blog.html" class="nav-link">BLOG</a>
            </li>
            <li class="nav-item">
              <a href="kontakt.php" class="nav-link">KONTAKT</a>
            </li>

            <li class="nav-item">
              <a href="index-uk.php" class="nav-link">
                <img
                  src="images/uk-zastava.png"
                  alt=""
                  style="height: 20px; width: 40px; border: 0.5px solid #154d32"
                />
              </a>
            </li>
            <li class="nav-item">
              <a href="index-ru.php" class="nav-link">
                <img
                  src="images/ruski-jezik.png"
                  alt=""
                  style="height: 20px; width: 40px; border: 0.5px solid #154d32"
                />
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <section class="home-slider owl-carousel">
      <div
        class="slider-item bread-item"
        style="background-image: url('images/o-nama-stranica.jpg')"
        data-stellar-background-ratio="0.5"
      >
        <div class="overlay"></div>
        <div class="container" data-scrollax-parent="true">
          <div class="row slider-text align-items-end">
            <div class="col-md-7 col-sm-12 ftco-animate mb-5">
              <h1
                class="mb-3"
                data-scrollax=" properties: { translateY: '70%', opacity: .9}"
              >
                KONTAKT
              </h1>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section contact-section ftco-degree-bg">
      <div class="container">
        <div class="row d-flex mb-5 contact-info">
          <div class="col-md-12 mb-4">
            <h2 class="h4">KONTAKT INFORMACIJE</h2>
          </div>
          <div class="w-100"></div>
          <div class="col-md-4">
            <a href="https://maps.app.goo.gl/viXz25ywssE4kNAd8">
              <p style="font-size: 16px">
                <span style="font-weight: bold">ADRESA:</span><br> Ulica Vojislava Ilića 137, Sprat 2, Zvezdara Beograd
              </p>
            </a>
          </div>
          <div class="col-md-4">
            <a href="tel:+381 60 190 9309">
              <p style="font-size: 16px">
                <span style="font-weight: bold">TELEFON:</span><br>
                <a href="tel:+381601909309"> +381 60/19-09-309</a><br>
                <a href="tel:+381117647210"> +381 11/764-72-10</a>
              </p>
            </a>
          </div>
          <div class="col-md-4">
            <a href="mailto:office@crystalclinic.rs">
              <p style="font-size: 16px">
                <span style="font-weight: bold">EMAIL ADRESA:</span><br>
                <a href="mailto:info@yoursite.com"> office@crystalclinic.rs</a>
              </p>
            </a>
          </div>
        </div>
        <div class="row block-9">
          <div class="col-md-6 pr-md-5">
            <form action="https://api.web3forms.com/submit" method="POST">
            
            <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
            
              <div class="form-group">
                <input name="Ime_i_prezime" type="text" class="form-control" placeholder="Ime i prezime" />
              </div>
              <div class="form-group">
                <input name="Email" type="email" class="form-control" placeholder="Email" />
              </div>
              <div class="form-group">
                <input name="Naslov" type="text" class="form-control" placeholder="Naslov" />
              </div>
              <div class="form-group">
                <textarea
                  name="Poruka"
                  id=""
                  cols="30"
                  rows="7"
                  class="form-control"
                  placeholder="Poruka"
                ></textarea>
              </div>
              <div class="form-group">
                <input
                  type="submit"
                  value="Pošaljite poruku"
                  class="btn btn-primary py-3 px-5"
                />
              </div>
            </form>
          </div>

          <div class="col-md-6">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22638.926595259367!2d20.444034286144067!3d44.824298048493375!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a7bb7d5be7f87%3A0x89ee408d58f06edb!2sCrystal%20Clinic!5e0!3m2!1sen!2srs!4v1717963555214!5m2!1sen!2srs"
              style="border: 0"
              allowfullscreen=""
              loading="lazy"
              referrerpolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </div>
    </section>

    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">
                <img
                  src="images/logo_1.png"
                  alt=""
                  style="height: 110px; width: 200px"
                />
              </h2>
              <p>
                Crystal Medical je vodeća klinika za estetsku hirurgiju posvećena
                postizanju vrhunskih rezultata kroz najmodernije tehnike i
                personalizovanu negu.
              </p>
            </div>
            <ul
              class="ftco-footer-social list-unstyled float-md-left float-lft"
            >
              <li class="ftco-animate">
                <a href="#"><span class="icon-instagram"></span></a>
              </li>
              <li class="ftco-animate">
                <a href="#"><span class="icon-facebook"></span></a>
              </li>
            </ul>
          </div>
          <div class="col-md-2">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">LINKOVI</h2>
              <ul class="list-unstyled">
                <li><a href="index.php" class="py-2 d-block">Početna</a></li>
                <li><a href="o-nama.html" class="py-2 d-block">O nama</a></li>
                <li><a href="usluge.html" class="py-2 d-block">Usluge</a></li>
                <li><a href="tim.html" class="py-2 d-block">Tim</a></li>
                <li><a href="blog.html" class="py-2 d-block">Blog</a></li>
                <li><a href="kontakt.php" class="py-2 d-block">Kontakt</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4 pr-md-4">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">BLOG OBJAVE</h2>
              <div class="block-21 mb-4 d-flex">
                <a
                  class="blog-img mr-4"
                  style="background-image: url(images/blog-1.avif)"
                ></a>
                <div class="text">
                  <h3 class="heading">
                    <a href="#"
                      >Kako se Pripremiti za Operaciju Estetske Hirurgije: Vodič
                      za Pacijente</a
                    >
                  </h3>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">KONTAKT</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li>
                    <a href="https://maps.app.goo.gl/viXz25ywssE4kNAd8">
                      <span class="icon icon-map-marker"></span
                      ><span class="text"
                        >Ulica Budimska 2, Dorćol, Beograd</span
                      >
                    </a>
                  </li>
                  <li>
                    <a href="tel:+381 60 190 9309"
                      ><span class="icon icon-phone"></span
                      ><span class="text">+381 60 190 9309</span></a
                    >
                    <a href="tel:+381 60 190 9309"
                      ><span class="icon icon-phone" style="color:transparent;"></span
                      ><span class="text">+381 11 764 7210</span></a
                    >
                  </li>
                  <li>
                    <a href="mailto:office@crystalclinic.rs"
                      ><span class="icon icon-envelope"></span
                      ><span class="text">office@crystalmedical.rs</span></a
                    >
                    <a href="mailto:info@crystalmedical.rs"
                      ><span class="icon icon-envelope" style="color:transparent;"></span
                      ><span class="text">info@crystalmedical.rs</span></a
                    >
                    <a href="mailto:drmihaila@crystalmedical.rs"
                      ><span class="icon icon-envelope" style="color:transparent;"></span
                      ><span class="text">drmihaila@crystalmedical.rs</span></a
                    >
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
            <p>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              &copy;
              <script>
                document.write(new Date().getFullYear());
              </script>
              Sva prava zadržana |
              <a href="https://apisdevelopment.rs" target="_blank"
                >Apis Development</a
              >
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
        </div>
      </div>
    </footer>

    <!-- loader -->
    <div id="preloader">
      <div class="logo">
        <img src="images/logo_1.png" alt="Logo" />
      </div>
    </div>

    <!-- Modal -->
    <div
      class="modal fade"
      id="modalRequest"
      tabindex="-1"
      role="dialog"
      aria-labelledby="modalRequestLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalRequestLabel">
              Make an Appointment
            </h5>
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="https://api.web3forms.com/submit"  method="POST">
              <div class="form-group">
                <!-- <label for="appointment_name" class="text-black">Full Name</label> -->
                
                <input type="hidden" name="access_key" value="29d4c912-6cb3-4a22-9190-7d50cf783ee7">
                
                <input
                  name="Ime i prezime"
                  type="text"
                  class="form-control"
                  id="appointment_name"
                  placeholder="Full Name"
                />
              </div>
              <div class="form-group">
                <!-- <label for="appointment_email" class="text-black">Email</label> -->
                <input
                  name="Email"
                  type="text"
                  class="form-control"
                  id="appointment_email"
                  placeholder="Email"
                />
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <!-- <label for="appointment_date" class="text-black">Date</label> -->
                    <input
                      name="Datum"
                      type="text"
                      class="form-control appointment_date"
                      placeholder="Date"
                    />
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <!-- <label for="appointment_time" class="text-black">Time</label> -->
                    <input
                      name="Vreme"
                      type="text"
                      class="form-control appointment_time"
                      placeholder="Time"
                    />
                  </div>
                </div>
              </div>

              <div class="form-group">
                <!-- <label for="appointment_message" class="text-black">Message</label> -->
                <textarea
                  name="Poruka"
                  id="appointment_message"
                  class="form-control"
                  cols="30"
                  rows="10"
                  placeholder="Message"
                ></textarea>
              </div>
              <div class="form-group">
                <input
                  type="submit"
                  value="Make an Appointment"
                  class="btn btn-primary"
                />
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-migrate-3.0.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/jquery.timepicker.min.js"></script>
    <script src="js/scrollax.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
    <script src="js/google-map.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
